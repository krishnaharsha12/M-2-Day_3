/* EXERCISE 1
 Write a piece of code to find the largest of  given two integers
*/
console.log(Math.max(5, 10));

console.log(Math.max(-5, -10));

console.log(Math.max(0, -0));

/* EXERCISE 2
  Write a piece of code to check: if  given an integer is NOT equal to 5 then display " not equal"
*/

let a=12;
if(a!=5){
console.log("Not equal")  //not equal
}

let b=12;
if(b!=12){
console.log("Not equal")  
}
/* EXERCISE 2
  Write a piece of code to check: if  given an integer is  divisible  by  5 then display "divisible by 5" (search for modulo operator)
*/
let c=35;
if(c % 5===0)
{
  console.log("Divisible by 5")
  }
else{
console.log("Not Divisible by 5")
}
/* WRITE YOUR ANSWER HERE */

/* EXERCISE 3
 Write a piece of code for checking if, given two integers, the value of one of them is 8 or if their addition or subtraction is equal to 8.
*/
let l=8;
    m=15;
    n=21.2;
let i=5;
    j=3;
let i1=12;
    j1=4;
const k=i+j;
const k1=i1-j1;
console.log(l);//one of them is 8
console.log(k);//addition is equal to 8.
console.log(k1);//subtraction is equal to 8.


/* EXERCISE 4
 You are working on an e-commerce website. In the variable totalShoppingCart you are storing the total amount spent by the current user.
 Currently you have a promotion: if the customer's shopping cart total is more than 50, the user is eligible for free shipping (otherwise it costs 10).
 Write an algorithm that calculates the total cost to charge the user with.
*/

// Free shipping
const quantityOfShirts = 2; 
const priceOfShirts = 8.99;

const quantityOfTrousers = 2; 
const priceOfTrousers = 9.99;

const quantityOfJacket = 1; 
const priceOfJacket = 15.99;

const quantityOfShoes = 1; 
const priceOfShoes = 25.99;


//Delivery costs $10
const quantityOfJumpers = 1; 
const tityOfJumpers = 15.99;

const quantityOfCrocs = 1; 
const priceOfCrocs = 29.99;

const quantityOfChocolates= 2;
const priceOfChocolates = 0.49;


const shirtsValue = quantityOfShirts * priceOfShirts
const trousersValue = quantityOfTrousers * priceOfTrousers
const jacketValue = quantityOfJacket * priceOfJacket
const shoesValue = quantityOfShoes * priceOfShoes


const jumpersValue = quantityOfJumpers * tityOfJumpers
const crocsValue = quantityOfCrocs * priceOfCrocs
const chocolatesValue = quantityOfChocolates * priceOfChocolates

const totalShoppingCart= shirtsValue + trousersValue + jacketValue + shoesValue

const totalShoppingCart1 =jumpersValue + crocsValue + chocolatesValue



console.log(totalShoppingCart);
console.log(totalShoppingCart1)

if(totalShoppingCart>50)
if(totalShoppingCart1>50)
{
  console.log("Free shipping")
  }
else
  console.log(totalShoppingCart1 + 10 );
/* EXERCISE 5
You are working on an e-commerce website. Today is Black Friday and everything has a 20% discount at the end of the purchase.
 Modify the previous answer inserting this information and, applying the same rules for the shipping cost, calculate the totalCost.
*/
let totalShopping1 = 96;
let per= 20;
if (totalShopping1 > 50) {
console.log((totalShopping1/100)*per)// Discount achieved
console.log(totalShopping1 * 0.8);
}
else console.log(cartTotal2 * 0.8 + 10);
console.log("Total after Discount")

/* EXERCISE 6
Create three variables and assign a numerical value to each one of them. 
 Using a conditional statement, write a piece of code for sorting their values from highest to lowest.
 Display the result in the console.
*/

console.log("one approach")

let numbers = [5, 13, -1, 44, 32]

let highestToLowest = numbers.sort((a, b) => b-a);

console.log(highestToLowest);

var p = 44;
var q = 32;
var r = -13;

if (p > q && p > r) {
  if (q > r) {
    console.log(p + "  " + q + "  " + r);
  } else {
    console.log(p + "  " + r + "  " + q);
  }
} else if (q > p && q > r) {
  if (p > r) {
    console.log(q + "  " + p + "  " + r);
  } else {
    console.log(q + "  " + r + "  " + p);
  }
} else if (r > p && r > q) {
  if (p > q) {
    console.log(r + "  " + p + "  " + q);
  } else {
    console.log(r + "  " + q + "  " + p);
  }
}

/* EXERCISE 7
Write a piece of code for checking if a given value is a integer or not. (search for 'typeof')
*/
let 
b1= Number.isInteger(15)
c= Number.isInteger(-13)
d= Number.isInteger(1.5)
e= Number.isInteger('lion')
console.log(b1);
console.log(c);
console.log(d);
console.log(e)

var s=15; 
if (typeof s === "value") {
  console.log("Integer");
} else {
  console.log("Not integer");
}
/* EXERCISE 8
 Write a piece of code for checking if a given number is even or odd. (search for modulo operator)
*/
const number = 12;
const number1= -5;
if(number % 2 == 0) {
  console.log("The given number is even.");
}
else {
  console.log("The given number is odd.");
}
if(number1 % 2 == 0) {
  console.log("The given number is even.");
}
else {
  console.log("The given number is odd.");
}

/* EXERCISE 9
Change the order of logic in the code so that it will return the correct statements in all cases.
let val = 7
if (val < 10) {
    console.log("Less than 10");
  } else if (val < 5) {
     console.log("Less than 5");
  } else {
    console.log("Greater than or equal to 10");
  }
*/
let val = 4.9
    val1 =  7
    val2 = 10
if (val < 5) {
  console.log("Less than 5");
}
else if (val < 10){
  console.log("Less than 10");
}
 else {
  console.log("Greater than or equal to 10");
}

if (val1 < 5) {
  console.log("Less than 5");
}
else if (val1 < 10){
  console.log("Less than 10");
}
 else {
  console.log("Greater than or equal to 10");
}
if (val2 < 5) {
  console.log("Less than 5");
}
else if (val2 < 10){
  console.log("Less than 10");
}
 else {
  console.log("Greater than or equal to 10");
}

/*
EXERCISE 10
Write chained if/else if statements to fulfill the following conditions:
num < 5 - display Tiny
num < 10 - display Small
num < 15 - display Medium
num < 20 - display Large
num >= 20 - display Huge
*/
let num=7;

  if (num < 5) {
   console.log("Tiny")
  }
  else if (num < 10)
  {
    console.log("Small");
  }
  else if (num < 15)
  { 
   console.log("Medium");
  }
  else if (num < 20)
  {
   console.log("Large");
  }
  else 
  console.log("Huge");

/*  EXERCISE 11
Use a ternary operator to assign to a variable called gender the string values "male" or "female".
 The choice should be made based on the value of another variable called isMale.
*/

let isMale = false ;
console.log(isMale ? "male" : "female");

/* EXERCISE 12
Display the numbers 0 through 5 (inclusive) in acesnding order using a while loop.
*/
var Arr = [1, 6, 2, 3, 4, 5, 0];

for (var d = 1; d < Arr.length; d++)
    for (var j = 0; j < d; j++)
        while (Arr[d] < Arr[j]) {
          var x = Arr[d];
          Arr[d] = Arr[j];
          Arr[j] = x;
        }
console.log(Arr);

/* EXERCISE 13
Display the numbers 0 through 10 (inclusive) in acesnding order using a for loop.
*/
var Arr = [1, 7, 2, 3, 4, 5, 0, 6, 8, 9, 10];

for (var d = 1; d < Arr.length; d++)
  for (var j = 0; j < d; j++)
    while (Arr[d] < Arr[j]) {
       var x = Arr[d];
       Arr[d] = Arr[j];
       Arr[j] = x;
        }
    console.log(Arr);
/* EXERCISE 14
Display the numbers 0 through 10 (inclusive) in acesnding order  but skip displaying 3 and 8.
*/
var Arr = [1, 7, 6, 2, 3, 4, 5, 0, 9, 8, 10];
for (var d = 1; d < Arr.length; d++)

for (var j = 0; j < d; j++)
  if (Arr !== 3 && Arr !== 5)
        while (Arr[d] < Arr[j]) {
          var x = Arr[d];
          Arr[d] = Arr[j];
          Arr[j] = x;
        }
console.log(Arr);
        
for (let i = 0; i < 10; i++) {
  if (i !== 3 && i !== 5) {
    console.log(i);
  }
}
/* EXERCISE 15
 Write a JavaScript for loop that will iterate from 0 to 15. For each iteration, it will check if the current number is odd or even, and display a message to the screen
*/
for (var x=0; x<=15; x++) {
  if (x === 0) {
          console.log(x +  " is even");
  }
  else if (x % 2 === 0) {
          console.log(x + " is even");   
  }
  else {
          console.log(x + " is odd");
  }
}


/* EXERCISE 16
  Write a JavaScript program which iterates the integers from 1 to 100. But for multiples of three print "Fizz" instead of the number and for the multiples of five print "Buzz". For numbers which are multiples of both three and five print "FizzBuzz
 */
  for (var x = 1; x < 100; x++) {
    if (x % 15 == 0) console.log("FizzBuzz");
    else if (x % 3 == 0) console.log("Fizz");
    else if (x % 5 == 0) console.log("Buzz");
    else console.log(x);
}

/* EXERCISE 17
  Write a piece of code to check the day of the week .  Use  SWITCH - CASE  and given "day" variable with range from 1 to 7. 
  For example: if day value is equal to 1 display "Monday", if day value is equal to 3 display "Wednesday"
*/
  let day = 1;
  switch (day) {
    case 0:
      console.log("It's Sunday");
      break;
    case 1:
      console.log("It's Monday!");
      break;
    case 2:
      console.log("It's Tuesday");
      break;
    case 3:
      console.log("It's Wednesday");
      break;
    case 4:
      console.log("It's Thrusday");
      break;
    case 5:
      console.log("It's Friday!");
      break;
    case 6:
      console.log("It's Saturday!");
      break;
  }