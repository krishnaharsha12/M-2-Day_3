var number = 90;

//The percent that we want to get.
//i.e. We want to get 50% of 120.
var percentToGet = 20;

//Calculate the percent.
var percent = (number/ 100) * percentToGet;
console.log(percent);